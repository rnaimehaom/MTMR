import os
import sys
MTMR_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir)) # ~/MTMR/DATA/jnk3 -> ~/MTMR
sys.path = sys.path if MTMR_PATH in sys.path else [MTMR_PATH] + sys.path

import pandas as pd
import numpy as np
import tqdm
from MTMR.properties import get_kekuleSmiles, similarity, jnk3



if __name__=="__main__":
    input_dir = os.path.abspath(os.path.dirname(__file__))
    output_dir = input_dir

    filepath_raw = os.path.join(input_dir, "all.txt")
    df_raw = pd.read_csv(filepath_raw).drop_duplicates(ignore_index=True)
    print(f"df_raw.shape: {df_raw.shape}")
    
    ## kekulization & score
    scoring_ft = jnk3()
    records = []
    for smi, y in tqdm.tqdm(df_raw.values):
        kek = get_kekuleSmiles(smi)
        records.append((kek, y, scoring_ft(kek)))
        
    df_kek = pd.DataFrame.from_records(records).drop_duplicates(ignore_index=True)
    print(f"df_kek.shape: {df_kek.shape}")
        
    ## source & target
    df_src = df_kek[df_kek.iloc[:,1] == 0].reset_index(drop=True)
    df_tar = df_kek[df_kek.iloc[:,1] == 1].reset_index(drop=True)
    print(f"df_src.shape: {df_src.shape}")
    print(f"df_tar.shape: {df_tar.shape}")
    
    ## train & test & validation split
    num_src = len(df_src)
    rng = np.random.default_rng(2022)
    idx = rng.permutation(num_src)
    
    df_te = df_src.iloc[idx[-1000:],:].reset_index(drop=True)
    df_va = df_src.iloc[idx[-1500:-1000],:].reset_index(drop=True)
    df_tr_src = df_src.iloc[idx[:-1500],:].reset_index(drop=True)
    print(f"df_te.shape: {df_te.shape}")
    print(f"df_va.shape: {df_va.shape}")
    print(f"df_tr_src.shape: {df_tr_src.shape}")
    
    ## Save test and validation
    df_te.to_csv(os.path.join(output_dir, "rdkit_test.txt"), sep=' ', header=None, index=False)
    df_va.to_csv(os.path.join(output_dir, "rdkit_valid.txt"), sep=' ', header=None, index=False)
    
    ## make paired train dataset
    records = []
    for i in tqdm.trange(num_src):
        smi_src = df_src.iloc[i,0]
        y_src = df_src.iloc[i,1]
        p_src = df_src.iloc[i,2]
        for smi_tar, y_tar, p_tar in df_tar.values:
            if similarity(smi_src, smi_tar) >= 0.4:
                records.append((smi_src, smi_tar, p_src, p_tar, y_src, y_tar))
    df_pair = pd.DataFrame.from_records(records)
    print(f"df_pair.shape: {df_pair.shape}")
    
    ## Save training
    df_pair.to_csv(os.path.join(output_dir, "rdkit_train_pairs.txt"), sep=' ', header=None, index=False)
    df_pair.iloc[:,[0,2,4]].drop_duplicates().to_csv(os.path.join(output_dir, "rdkit_train_src.txt"), sep=' ', header=None, index=False)
    df_pair.iloc[:,[1,3,5]].drop_duplicates().to_csv(os.path.join(output_dir, "rdkit_train_tar.txt"), sep=' ', header=None, index=False)
    
