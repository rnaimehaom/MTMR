import os
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import tqdm
from rdkit.Chem import MolFromSmiles, MolToSmiles

def get_kekuleSmiles(smi):
    mol = MolFromSmiles(smi)
    smi_rdkit = MolToSmiles(
                    mol,
                    isomericSmiles=False,   # modified because this option allows special tokens (e.g. [125I])
                    kekuleSmiles=True,      # modified for downstream analysis with rdkit
                    rootedAtAtom=-1,        # default
                    canonical=True,         # default
                    allBondsExplicit=False, # default
                    allHsExplicit=False     # default
                )
    return smi_rdkit

if __name__=="__main__":
    input_dir = "."
    output_dir = "."

    filepath_tr = os.path.join(input_dir, "train_pairs.txt")
    filepath_te = os.path.join(input_dir, "test.txt")
    filepath_va = os.path.join(input_dir, "valid.txt")
    
    df_tr = pd.read_csv(filepath_tr, sep=" ", header=None).rename(columns={0:"source", 1:"target"})
    df_te = pd.read_csv(filepath_te, header=None).rename(columns={0:"source"})
    df_va = pd.read_csv(filepath_va, header=None).rename(columns={0:"source"})

    print(f"df_tr.shape: {df_tr.shape}")
    print(f"df_te.shape: {df_te.shape}")
    print(f"df_va.shape: {df_va.shape}")
    
    df_tr_rdkit = df_tr.copy()
    df_tr_rdkit["source"] = [get_kekuleSmiles(smi) for smi in tqdm.tqdm(df_tr["source"])]
    df_tr_rdkit["target"] = [get_kekuleSmiles(smi) for smi in tqdm.tqdm(df_tr["target"])]
    
    df_te_rdkit = df_te.copy()
    df_va_rdkit = df_va.copy()
    df_te_rdkit["source"] = [get_kekuleSmiles(smi) for smi in tqdm.tqdm(df_te["source"])]
    df_va_rdkit["source"] = [get_kekuleSmiles(smi) for smi in tqdm.tqdm(df_va["source"])]
    
    df_tr_rdkit.loc[:,"source"].to_csv(os.path.join(input_dir, "rdkit_train_src.txt"), sep=" ", index=False, header=False)
    df_tr_rdkit.loc[:,"target"].to_csv(os.path.join(input_dir, "rdkit_train_tar.txt"), sep=" ", index=False, header=False)
    
    df_tr_rdkit.to_csv(os.path.join(input_dir, "rdkit_train_pairs.txt"), sep=" ", index=False, header=False)
    df_te_rdkit.to_csv(os.path.join(input_dir, "rdkit_test.txt"), sep=" ", index=False, header=False)
    df_va_rdkit.to_csv(os.path.join(input_dir, "rdkit_valid.txt"), sep=" ", index=False, header=False)